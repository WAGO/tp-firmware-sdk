
//  Linux Frame Buffer Device Configuration
//
//  � Copyright 1995-1999 by Geert Uytterhoeven <geert@linux-m68k.org>
//
//  --------------------------------------------------------------------------
//
//  This file is subject to the terms and conditions of the GNU General Public
//  License. See the file COPYING in the main directory of the Linux
//  distribution for more details.


#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>

#include "config.h"
#include "database.h"
#include "util.h"


extern FILE *y2in;
extern int y2parse(void);


static bool Opt_version = false;
static bool Opt_verbose = false;
static bool Opt_quiet = false;
static const char *Opt_debug = NULL;
const char *Opt_modedb = NULL;

enum { ID_HELP = 1 };

const struct option Options[] = {
    { ID_HELP, 'h', "help", NULL, 0 },
    { 0, 'V', "version", &Opt_version, 0 },
    { 0, 'v', "verbose", &Opt_verbose, 0 },
    { 0, 'q', "quiet", &Opt_quiet, 0 },
};

u_int DebugMask = 0;


    //  Print the Usage Template and Exit

static void Usage(void)
{
    puts(VERSION);
    Die("\nUsage: %s [options] [mode]\n\n"
	"Valid options:\n"
	"  General options:\n"
	"    -h, --help         : display this usage information\n"
	"    --test             : don't change, just test whether the mode is "
				 "valid\n"
	"    -s, --show         : display video mode settings\n"
	"    -i, --info         : display all frame buffer information\n"
	"    -v, --verbose      : verbose mode\n"
	"    -V, --version      : print version information\n"
	"    -x, --xfree86      : XFree86 compatibility mode\n"
	"    -a, --all          : change all virtual consoles on this device\n"
	"n", ProgramName);
}


    //  Main Routine

int main(int argc, char *argv[])
{
    int id;

    //  Parse the Options

    while ((id = GetNextOption(argc, argv, Options,
			       sizeof(Options)/sizeof(*Options))))
	switch (id) {
	    case ID_HELP:
		Usage();

	    default:
		if (Opt_modedb)
		    Usage();
		Opt_modedb = argv[0];
		argc--;
		argv++;
	}
    if (Opt_debug)
	DebugMask = strtoul(Opt_debug, NULL, 0);

    if (Opt_version || Opt_verbose)
	puts(VERSION);

    if (Opt_modedb) {
	if (Opt_verbose)
	    printf("Reading mode database from file `%s'\n", Opt_modedb);
	if (!(y2in = fopen(Opt_modedb, "r")))
	    Die("fopen %s: %s\n", Opt_modedb, strerror(errno));
    } else
	y2in = stdin;
    y2parse();
    if (Opt_modedb)
	fclose(y2in);
    DumpDatabase();

    exit(0);
}
