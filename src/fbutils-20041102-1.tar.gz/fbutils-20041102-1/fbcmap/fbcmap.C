#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/fcntl.h>
#include <sys/types.h>
#include <sys/mman.h>

#include "config.h"
#include "framebuffer.h"
#include "util.h"


bool Opt_version = false;
bool Opt_verbose = false;
const char *Opt_debug = NULL;
const char *Opt_fb = DEFAULT_FRAMEBUFFER;
const char *Opt_length = NULL;
const char *Opt_command = NULL;

enum { ID_HELP = 1 };

const struct option Options[] = {
    { ID_HELP, 'h', "help", NULL, 0 },
    { 0, 'V', "version", &Opt_version, 0 },
    { 0, 'v', "verbose", &Opt_verbose, 0 },
    { 0, 0, "debug", &Opt_debug, 0 },
    { 0, 'f', "frame-buffer", &Opt_fb, 1 },
    { 0, 'l', "length", &Opt_length, 1 },
};

u_int DebugMask = 0;


static __u16 VGA_Red[16] = {
    0x0000, 0x0000, 0x0000, 0x0000, 0xaaaa, 0xaaaa, 0xaaaa, 0xaaaa,
    0x5555, 0x5555, 0x5555, 0x5555, 0xffff, 0xffff, 0xffff, 0xffff
};

static __u16 VGA_Green[16] = {
    0x0000, 0x0000, 0xaaaa, 0xaaaa, 0x0000, 0x0000, 0xaaaa, 0xaaaa,
    0x5555, 0x5555, 0xffff, 0xffff, 0x5555, 0x5555, 0xffff, 0xffff
};

static __u16 VGA_Blue[16] = {
    0x0000, 0xaaaa, 0x0000, 0xaaaa, 0x0000, 0xaaaa, 0x0000, 0xaaaa,
    0x5555, 0xffff, 0x5555, 0xffff, 0x5555, 0xffff, 0x5555, 0xffff
};


    //  Print the Usage Template and Exit

static void Usage(void)
{
    Die("\nUsage: %s [options]\n\n"
	"Valid options are:\n"
	"    -h, --help             : Display this usage information and exit\n"
	"    -v, --verbose          : Verbose mode\n"
	"    -l, --length len       : Colormap length\n"
	"    -f, --frame-buffer dev : Framebuffer device to use\n"
	"    -d, --dump             : Dump the colormap (default operation)\n"
	"    -r, --ramp             : Set the colormap to a ramp\n"
	"    -c, --vga              : Set the colormap to the VGA console "
				     "palette\n"
	"    -i, --inverse          : Invert the current colormap\n"
	"\n", ProgramName);
}


    //  Main Routine

int main(int argc, char *argv[])
{
    int id;
     u_int length, numcolorcells;

    while ((id = GetNextOption(argc, argv, Options,
			       sizeof(Options)/sizeof(*Options))))
	switch (id) {
	    case ID_HELP:
		Usage();

	    default:
		if (Opt_command)
		    Usage();
		Opt_command = argv[0];
		argc--;
		argv++;
	}
    if (Opt_debug)
	DebugMask = strtoul(Opt_debug, NULL, 0);

    if (Opt_version || Opt_verbose)
	puts(VERSION);

    FrameBuffer fb(Opt_fb);
    VarScreenInfo var;
    var.Get(fb);
    FixScreenInfo fix;
    fix.Get(fb);

    switch (fix.visual) {
	case FB_VISUAL_MONO01:
	case FB_VISUAL_MONO10:
	    numcolorcells = 2;
	    break;

	case FB_VISUAL_TRUECOLOR:
	    numcolorcells = 0;
	    break;

	case FB_VISUAL_DIRECTCOLOR:
	    numcolorcells = 1<<(var.red.length >? var.green.length >?
				var.blue.length);
	    break;

	case FB_VISUAL_PSEUDOCOLOR:
	case FB_VISUAL_STATIC_PSEUDOCOLOR:
	default:
	    numcolorcells = 1ULL<<var.bits_per_pixel;
	    break;
    }
    if (Opt_length)
	length = atoi(Opt_length);
    else
	length = numcolorcells;
    if (length > numcolorcells)
	Warn("Warning: length > number of color cels \n");
    ColorMap cmap(length);

    if (!Opt_command || !strcmp(Opt_command, "dump")) {
	cmap.Get(fb);
	cmap.Print();
    } else if (!strcmp(Opt_command, "ramp")) {
	for (u_int i = 0; i < cmap.len; i++) {
	    double val = 65535.0*i/(cmap.len-1);
	    cmap.red[i] = (__u16)val;
	    cmap.green[i] = (__u16)val;
	    cmap.blue[i] = (__u16)val;
	}
	cmap.Set(fb);
    } else if (!strcmp(Opt_command, "vga")) {
	u_int len = cmap.len <? 16;
	memcpy(cmap.red, VGA_Red, len*sizeof(*cmap.red));
	memcpy(cmap.green, VGA_Green, len*sizeof(*cmap.green));
	memcpy(cmap.blue, VGA_Blue, len*sizeof(*cmap.blue));
	if (cmap.transp)
	    memset(cmap.transp, 0, len*sizeof(*cmap.red));
	if (cmap.len > len) {
	    len = cmap.len-len;
	    memset(&cmap.red[16], 0, len*sizeof(*cmap.red));
	    memset(&cmap.green[16], 0, len*sizeof(*cmap.green));
	    memset(&cmap.blue[16], 0, len*sizeof(*cmap.blue));
	}
	cmap.Set(fb);
    } else if (!strcmp(Opt_command, "invert")) {
	cmap.Get(fb);
	cmap.Invert();
	cmap.Set(fb);
    } else
	Die("Unknown command `%s'\n", Opt_command);

    exit(0);
}
