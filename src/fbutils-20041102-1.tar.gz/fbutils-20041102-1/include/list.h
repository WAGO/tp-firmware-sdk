
#ifndef __LIST_H
#define __LIST_H

    //	Simple lists
    //
    //	Former AmigaOS programmers may experience a `d�j� vu' feeling


#include <assert.h>
#include <stdio.h>


    //	List Node

class Node {
    friend class List;
    public:
	Node(const char *name = NULL);
	virtual ~Node();
    public:
	Node *GetNext(void) const;
	Node *GetPrev(void) const;
	const char *GetName(void) const;

	void Insert(Node *pred);
	void Remove(void);

	virtual void Dump(bool in_list = false) const;

    protected:
	Node *Succ;
	Node *Pred;
	char *Name;
};

inline Node *Node::GetNext(void) const
{
    assert(Succ != NULL);
    assert(Pred != NULL);
    return Succ->Succ ? Succ : (Node *)NULL;
}

inline Node *Node::GetPrev(void) const
{
    assert(Succ != NULL);
    assert(Pred != NULL);
    return Pred->Pred ? Pred : (Node *)NULL;
}


    //	List Header

class List {
    public:
	List(const char *name);
	virtual ~List();

	Node *GetHead(void) const;
	Node *GetTail(void) const;

	void AddHead(Node *node);
	void AddTail(Node *node);
	Node *RemHead(void);
	Node *RemTail(void);

	bool operator!(void) const;
	void Add(Node *node);
	virtual Node *Find(const char *name, bool use_aliases = true) const;

	void Dump(void) const;

    protected:
	Node Head;
	Node Tail;
	char *Name;
};

inline Node *List::GetHead(void) const
{
    assert(Head.Succ != NULL);
    return Head.Succ->Succ ? Head.Succ : (Node *)NULL;
}

inline Node *List::GetTail(void) const
{
    assert(Tail.Pred != NULL);
    return Tail.Pred->Pred ? Tail.Pred : (Node *)NULL;
}

inline bool List::operator!(void) const
{
    return Head.Succ == &Tail ? true : false;
}


    //  List of Aliases

class AliasNode : public Node {
    public:
	AliasNode(const char *name, const char *alias);
	void Dump(bool in_list = false) const;
	const char *GetAlias(void) const;

    private:
	char *Alias;
};

class AliasList : public List {
    public:
	AliasList();

	AliasNode *Find(const char *name, bool use_aliases = false) const;
};


    //  Inline functions

inline AliasNode *AliasList::Find(const char *name, bool use_aliases) const
{
    return (AliasNode *)List::Find(name, use_aliases);
}

inline const char *AliasNode::GetAlias(void) const
{
    return Alias;
}

extern AliasList Aliases;

#endif	// __LIST_H

