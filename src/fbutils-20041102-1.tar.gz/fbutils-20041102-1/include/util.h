
#ifndef __UTIL_H
#define __UTIL_H

#include <sys/types.h>

struct option {
    u_int id;		// must be > 0
    char short_key;
    const char *long_key;
    void *store_args;	// (bool *) if num_args == 0, (const char **) else
    u_int num_args;
};


extern const char *ProgramName;


    //  Function Prototypes

extern void Die(const char *fmt,...) __attribute__((noreturn));
extern void Warn(const char *fmt,...);
extern int GetNextOption(int &argc, const char **&argv,
			 const struct option options[],
			 const u_int num_options);

#endif	// __UTIL_H

