
#ifndef __FRAME_BUFFER_H
#define __FRAME_BUFFER_H

#include <sys/types.h>

#include "fb.h"

class FrameBuffer {
    public:
	FrameBuffer(const char *name, bool read_write = false);
	~FrameBuffer();
	int Ioctl(unsigned long request, void *p = NULL) const;

    private:
	int fd;
};

class FixScreenInfo : public fb_fix_screeninfo {
    public:
	void Get(const FrameBuffer &fb);
	void Print(const char *indent = "") const;
};

class Videomode;

class VarScreenInfo : public fb_var_screeninfo {
    public:
	VarScreenInfo();
	VarScreenInfo(const Videomode &mode);
	void Get(const FrameBuffer &fb);
	void Set(const FrameBuffer &fb, bool all = false);
	bool Try(const FrameBuffer &fb);
	void Print(const char *indent = "") const;
	void XFree86(const char *indent = "") const;
};

class ColorMap : public fb_cmap {
    public:
	ColorMap(u_int len_, u_int start_ = 0, bool transp_ = false);
	~ColorMap();
	void Get(const FrameBuffer &fb);
	void Set(const FrameBuffer &fb) const;
	void Invert(void) const;
	void Print(const char *indent = "") const;
};

class Con2FBMap : public fb_con2fbmap {
    public:
	void Get(const FrameBuffer &fb);
	void Set(const FrameBuffer &fb) const;
	void Print(const char *indent = "") const;
};

#endif	// __FRAME_BUFFER_H

