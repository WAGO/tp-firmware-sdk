#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>

#include "config.h"
#include "framebuffer.h"
#include "util.h"


bool Opt_version = false;
bool Opt_verbose = false;
const char *Opt_debug = NULL;
const char *Opt_fb = DEFAULT_FRAMEBUFFER;
const char *Opt_console = NULL;
const char *Opt_framebuffer = NULL;


enum { ID_HELP = 1 };

const struct option Options[] = {
    { ID_HELP, 'h', "help", NULL, 0 },
    { 0, 'V', "version", &Opt_version, 0 },
    { 0, 'v', "verbose", &Opt_verbose, 0 },
    { 0, 0, "debug", &Opt_debug, 0 },
    { 0, 'f', "frame-buffer", &Opt_fb, 1 },
};

u_int DebugMask = 0;


    //  Print the Usage Template and Exit

static void Usage(void)
{
    Die("\nUsage: %s [options] console [framebuffer]\n\n"
	"Valid options are:\n"
	"    -h, --help             : Display this usage information and "
				      "exit\n"
	"    -v, --verbose          : Verbose mode\n"
	"    -f, --frame-buffer dev : Framebuffer device to usei (default: "
				      "%s)\n"
	"\n", ProgramName, Opt_fb);
}

int main(int argc, char *argv[])
{
    int id;

    while ((id = GetNextOption(argc, argv, Options,
			       sizeof(Options)/sizeof(*Options))))
	switch (id) {
	    case ID_HELP:
		Usage();

	    default:
		if (!Opt_console)
		    Opt_console = argv[0];
		else if (!Opt_framebuffer)
		    Opt_framebuffer = argv[0];
		else
		    Usage();
		argc--;
		argv++;
	}
    if (Opt_debug)
	DebugMask = strtoul(Opt_debug, NULL, 0);

    if (Opt_version || Opt_verbose)
	puts(VERSION);

    FrameBuffer fb(Opt_fb);
    Con2FBMap map;
    if (!Opt_console)
	Usage();
    map.console = atoi(Opt_console);
    if (Opt_framebuffer) {
	map.framebuffer = atoi(Opt_framebuffer);
	map.Set(fb);
    } else {
	map.Get(fb);
	map.Print();
    }

    exit(0);
}
