
//  Linux Frame Buffer Device Configuration
//
//  � Copyright 1995-1999 by Geert Uytterhoeven <geert@linux-m68k.org>
//
//  --------------------------------------------------------------------------
//
//  This file is subject to the terms and conditions of the GNU General Public
//  License. See the file COPYING in the main directory of the Linux
//  distribution for more details.


#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/ioctl.h>

#include "config.h"
#include "database.h"
#include "util.h"


bool Opt_version = false;
bool Opt_verbose = false;
bool Opt_quiet = false;
bool Opt_show = false;
bool Opt_dump = false;
bool Opt_just_print = false;
bool Opt_info = false;
const char *Opt_debug = NULL;
const char *Opt_fb = DEFAULT_FRAMEBUFFER;
const char *Opt_modedb = DEFAULT_MODEDBFILE;
const char *Opt_modename = NULL;

enum { ID_HELP = 1, ID_HELP_MODIFY, ID_MOVE, ID_STEP };

const char *Modify_xres = NULL;
const char *Modify_yres = NULL;
const char *Modify_vxres = NULL;
const char *Modify_vyres = NULL;
const char *Modify_depth = NULL;
const char *Modify_accel = NULL;
const char *Modify_pixclock = NULL;
const char *Modify_left = NULL;
const char *Modify_right = NULL;
const char *Modify_upper = NULL;
const char *Modify_lower = NULL;
const char *Modify_hslen = NULL;
const char *Modify_vslen = NULL;
const char *Modify_hsync = NULL;
const char *Modify_vsync = NULL;
const char *Modify_csync = NULL;
const char *Modify_gsync = NULL;
const char *Modify_extsync = NULL;
const char *Modify_bcast = NULL;
const char *Modify_laced = NULL;
const char *Modify_double = NULL;
const char *Modify_move = NULL;
const char *Modify_step = NULL;

const struct option Options[] = {
    { ID_HELP, 'h', "help", NULL, 0 },
    { 0, 'V', "version", &Opt_version, 0 },
    { 0, 'v', "verbose", &Opt_verbose, 0 },
    { 0, 'q', "quiet", &Opt_quiet, 0 },
    { 0, 's', "show", &Opt_show, 0 },
    { 0, 'd', "dump", &Opt_dump, 0 },
    { 0, 'n', "just-print", &Opt_just_print, 0 },
    { 0, 'i', "info", &Opt_info, 0 },
    { 0, 0, "debug", &Opt_debug, 0 },
    { 0, 'f', "frame-buffer", &Opt_fb, 1 },
    { 0, 'm', "mode-db", &Opt_modedb, 1 },
    { 0, 'x', "xres", &Modify_xres, 1 },
    { 0, 'y', "yres", &Modify_yres, 1 },
    { 0, 0, "vxres", &Modify_vxres, 1 },
    { 0, 0, "vyres", &Modify_vyres, 1 },
    { 0, 'b', "bpp", &Modify_depth, 1 },
    { 0, 'a', "accel", &Modify_accel, 1 },
    { 0, 0, "pixclock", &Modify_pixclock, 1 },
    { 0, 0, "left", &Modify_left, 1 },
    { 0, 0, "right", &Modify_right, 1 },
    { 0, 0, "upper", &Modify_upper, 1 },
    { 0, 0, "lower", &Modify_lower, 1 },
    { 0, 0, "hslen", &Modify_hslen, 1 },
    { 0, 0, "vslen", &Modify_vslen, 1 },
    { 0, 0, "hsync", &Modify_hsync, 1 },
    { 0, 0, "vsync", &Modify_vsync, 1 },
    { 0, 0, "csync", &Modify_csync, 1 },
    { 0, 0, "gsync", &Modify_gsync, 1 },
    { 0, 0, "extsync", &Modify_extsync, 1 },
    { 0, 0, "bcast", &Modify_bcast, 1 },
    { 0, 0, "laced", &Modify_laced, 1 },
    { 0, 0, "double", &Modify_double, 1 },
    { ID_MOVE, 0, "move", NULL, 1 },
    { ID_STEP, 0, "step", NULL, 1 },
};

u_int DebugMask = 0;


    //  Function Prototypes

static void ReadDatabase(void);
static bool ModifyVideomode(Videomode &mode);


    //  Read the Video Mode Database

static void ReadDatabase(void)
{
    if (Opt_verbose)
	printf("Reading mode database from file `%s'\n", Opt_modedb);

    ReadDatabase(Opt_modedb);
}


    //  Modify a Video Mode

static bool ModifyVideomode(Videomode &mode)
{
    //

    u_int hstep = 8, vstep = 2;

    if (Modify_xres)
	{} // vmode.xres = strtoul(Modify_xres, NULL, 0);
    if (Modify_yres)
	{} // vmode.yres = strtoul(Modify_yres, NULL, 0);
    if (Modify_vxres)
	{} // vmode.vxres = strtoul(Modify_vxres, NULL, 0);
    if (Modify_vyres)
	{} // vmode.vyres = strtoul(Modify_vyres, NULL, 0);
    if (Modify_depth)
	{} // vmode.depth = strtoul(Modify_depth, NULL, 0);
    if (Modify_accel)
	{} // vmode.accel_flags = atoboolean(Modify_accel) ? FB_ACCELF_TEXT : 0;
    if (Modify_pixclock)
	{} // vmode.pixclock = strtoul(Modify_pixclock, NULL, 0);
    if (Modify_left)
	{} // vmode.left = strtoul(Modify_left, NULL, 0);
    if (Modify_right)
	{} // vmode.right = strtoul(Modify_right, NULL, 0);
    if (Modify_upper)
	{} // vmode.upper = strtoul(Modify_upper, NULL, 0);
    if (Modify_lower)
	{} // vmode.lower = strtoul(Modify_lower, NULL, 0);
    if (Modify_hslen)
	{} // vmode.hslen = strtoul(Modify_hslen, NULL, 0);
    if (Modify_vslen)
	{} // vmode.vslen = strtoul(Modify_vslen, NULL, 0);
    if (Modify_hsync)
	{} // vmode.hsync = atoboolean(Modify_hsync);
    if (Modify_vsync)
	{} // vmode.vsync = atoboolean(Modify_vsync);
    if (Modify_csync)
	{} // vmode.csync = atoboolean(Modify_csync);
    if (Modify_gsync)
	{} // vmode.gsync = atoboolean(Modify_gsync);
    if (Modify_extsync)
	{} // vmode.extsync = atoboolean(Modify_extsync);
    if (Modify_bcast)
	{} // vmode.bcast = atoboolean(Modify_bcast);
    if (Modify_laced)
	{} // vmode.laced = atoboolean(Modify_laced);
    if (Modify_double)
	{} // vmode.dblscan = atoboolean(Modify_double);
    if (Modify_step)
	hstep = vstep = strtoul(Modify_step, NULL, 0);
    if (Modify_move) {
	{} //
    }
    return false;
}


    //  Print the Usage Template and Exit

static void Usage(void)
{
    puts(VERSION);
    Die("\nUsage: %s [options] [mode]\n\n"
	"Valid options:\n"
	"  General options:\n"
	"    -h, --help         : display this usage information\n"
	"    --test             : don't change, just test whether the mode is "
				 "valid\n"
	"    -s, --show         : display video mode settings\n"
	"    -i, --info         : display all frame buffer information\n"
	"    -v, --verbose      : verbose mode\n"
	"    -V, --version      : print version information\n"
	"    -x, --xfree86      : XFree86 compatibility mode\n"
	"    -a, --all          : change all virtual consoles on this device\n"
	"  Frame buffer special device nodes:\n"
	"    -fb <device>       : processed frame buffer device\n"
	"                         (default is %s)\n"
	"  Video mode database:\n"
	"    -db <file>         : video mode database file\n"
	"                         (default is %s)\n"
	"  Display geometry:\n"
	"    -xres <value>      : horizontal resolution (in pixels)\n"
	"    -yres <value>      : vertical resolution (in pixels)\n"
	"    -vxres <value>     : virtual horizontal resolution (in pixels)\n"
	"    -vyres <value>     : virtual vertical resolution (in pixels)\n"
	"    -depth <value>     : display depth (in bits per pixel)\n"
	"    -g, --geometry ... : set all geometry parameters at once\n"
	"  Display timings:\n"
	"    -pixclock <value>  : pixel clock (in picoseconds)\n"
	"    -left <value>      : left margin (in pixels)\n"
	"    -right <value>     : right margin (in pixels)\n"
	"    -upper <value>     : upper margin (in pixel lines)\n"
	"    -lower <value>     : lower margin (in pixel lines)\n"
	"    -hslen <value>     : horizontal sync length (in pixels)\n"
	"    -vslen <value>     : vertical sync length (in pixel lines)\n"
	"    -t, --timings ...  : set all timing parameters at once\n"
	"  Display flags:\n"
	"    -accel <value>     : hardware text acceleration enable (false or "
				 "true)\n"
	"    -hsync <value>     : horizontal sync polarity (low or high)\n"
	"    -vsync <value>     : vertical sync polarity (low or high)\n"
	"    -csync <value>     : composite sync polarity (low or high)\n"
	"    -gsync <value>     : synch on green (false or true)\n"
	"    -extsync <value>   : external sync enable (false or true)\n"
	"    -bcast <value>     : broadcast enable (false or true)\n"
	"    -laced <value>     : interlace enable (false or true)\n"
	"    -double <value>    : doublescan enable (false or true)\n"
	"  Display positioning:\n"
	"    -move <direction>  : move the visible part (left, right, up or "
				 "down)\n"
	"    -step <value>      : step increment (in pixels or pixel lines)\n"
	"                         (default is 8 horizontal, 2 vertical)\n",
	ProgramName, Opt_fb, Opt_modedb);
}


    //  Main Routine

int main(int argc, char *argv[])
{
    int id;
    bool changed;

    //  Parse the Options

    while ((id = GetNextOption(argc, argv, Options,
			       sizeof(Options)/sizeof(*Options))))
	switch (id) {
	    case ID_HELP:
		Usage();

	    default:
		if (Opt_modename)
		    Usage();
		Opt_modename = argv[0];
		argc--;
		argv++;
	}
    if (Opt_debug)
	DebugMask = strtoul(Opt_debug, NULL, 0);

    if (Opt_version || Opt_verbose)
	puts(VERSION);

    FrameBuffer fb(Opt_fb);

    if (Opt_info) {
	FixScreenInfo fix;
	fix.Get(fb);
	fix.Print();
    }
    Videomode *mode;
    if (Opt_modename) {
	ReadDatabase();
	if (Opt_dump)
	    DumpDatabase();
	mode = Videomodes.Find(Opt_modename);
    } else {
	VarScreenInfo var;
	var.Get(fb);
	mode = new Videomode(var);
	mode->Dump();
    }

    changed = ModifyVideomode(*mode);

    if (changed && !Opt_just_print) {
	VarScreenInfo var(*mode);
	var.Set(fb);
    }

    exit(0);
}
