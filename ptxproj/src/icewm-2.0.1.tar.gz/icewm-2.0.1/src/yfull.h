#ifndef __YFULL_H
#define __YFULL_H

#include "ykey.h"

#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <X11/cursorfont.h>

#endif

// vim: set sw=4 ts=4 et:
