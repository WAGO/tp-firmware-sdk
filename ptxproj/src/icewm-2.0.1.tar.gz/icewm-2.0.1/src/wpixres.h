#ifndef __WPIXRES_H
#define __WPIXRES_H

class WPixRes {
public:

    static void initPixmaps();
    static void freePixmaps();

};

#endif

// vim: set sw=4 ts=4 et:
