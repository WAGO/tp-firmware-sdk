#include"extractor.h"

int func4(void) {
    return 4;
}
