#include <stdio.h>

#include "alltogether.h"

int main(void) {
    printf("%s - %s - %s - %s\n", res1, res2, res3, res4);
    return 0;
}
