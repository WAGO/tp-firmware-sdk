#!/bin/sh
exec autoreconf --install
rm -rf autom4te.cache
