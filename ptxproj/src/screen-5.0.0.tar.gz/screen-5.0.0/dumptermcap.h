#ifndef SCREEN_DUMPTERMCAP_H
#define SCREEN_DUMPTERMCAP_H

void  DumpTermcap (int, FILE *);

#endif /* SCREEN_DUMPTERMCAP_H */
