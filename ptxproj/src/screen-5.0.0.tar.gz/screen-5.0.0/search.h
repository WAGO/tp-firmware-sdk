#ifndef SCREEN_SEARCH_H
#define SCREEN_SEARCH_H

#include <stdbool.h>

void  Search (int);
void  ISearch (int);

/* global variables */

extern bool search_ic;

#endif /* SCREEN_SEARCH_H */
