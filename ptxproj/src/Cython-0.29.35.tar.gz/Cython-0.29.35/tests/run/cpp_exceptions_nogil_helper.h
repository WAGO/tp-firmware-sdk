void foo(int i) {
  if (i==0)
    return;
  else
    throw i;
}
