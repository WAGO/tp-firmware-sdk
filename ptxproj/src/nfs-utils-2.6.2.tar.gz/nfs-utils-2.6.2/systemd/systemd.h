#ifndef SYSTEMD_H
#define SYSTEMD_H

char *systemd_escape(char *path, char *suffix);

#endif /* SYSTEMD_H */
