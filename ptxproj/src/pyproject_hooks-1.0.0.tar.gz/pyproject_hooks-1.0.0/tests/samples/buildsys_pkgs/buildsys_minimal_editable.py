from buildsys_minimal import build_sdist, build_wheel  # noqa

build_editable = build_wheel
