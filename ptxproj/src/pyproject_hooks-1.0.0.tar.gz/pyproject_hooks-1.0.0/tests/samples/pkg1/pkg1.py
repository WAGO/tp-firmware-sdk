"""Sample package for tests"""

__version__ = '0.5'
