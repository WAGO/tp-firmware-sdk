```{caution}
This API is not finalised, and may change in a patch version.
```

# `installer.sources`

```{eval-rst}
.. automodule:: installer.sources
    :members:
```
