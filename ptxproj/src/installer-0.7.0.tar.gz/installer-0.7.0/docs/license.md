# License

This project's source code and documentation is under the following license:

```{include} ../LICENSE

```
