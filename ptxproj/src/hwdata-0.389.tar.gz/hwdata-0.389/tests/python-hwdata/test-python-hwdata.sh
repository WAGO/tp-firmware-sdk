#!/bin/sh -eux

python3 /usr/share/doc/python3-hwdata/example.py
