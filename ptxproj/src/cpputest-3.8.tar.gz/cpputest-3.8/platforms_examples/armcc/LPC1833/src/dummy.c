/* this file is requred to build application library, armar.exe can't build
 * libraries without at least one object input file.
*/
