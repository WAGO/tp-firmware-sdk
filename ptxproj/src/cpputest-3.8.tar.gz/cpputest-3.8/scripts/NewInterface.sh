#!/bin/bash
TEMPLATE_DIR=${CPPUTEST_HOME}/scripts/templates
source ${CPPUTEST_HOME}/scripts/GenerateSrcFiles.sh ClassName cpp Mock $1 $2
