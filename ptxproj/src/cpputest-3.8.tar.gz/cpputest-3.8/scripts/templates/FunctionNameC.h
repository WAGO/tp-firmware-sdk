#ifndef D_ClassName_H
#define D_ClassName_H

/**********************************************************
 *
 * ClassName is responsible for ...
 *
 **********************************************************/

void ClassName();

#endif  /* D_FakeClassName_H */
