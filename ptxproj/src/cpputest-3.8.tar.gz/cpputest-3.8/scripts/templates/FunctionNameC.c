#include "ClassName.h"

void ClassName()
{
}
