#ifndef THEMINST_H
#define THEMINST_H

void install_theme(const char* name);

#endif
