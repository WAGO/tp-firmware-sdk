def some_function():
    pass
